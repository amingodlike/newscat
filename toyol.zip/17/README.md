# NewscatBOT
Bot for Newscat
